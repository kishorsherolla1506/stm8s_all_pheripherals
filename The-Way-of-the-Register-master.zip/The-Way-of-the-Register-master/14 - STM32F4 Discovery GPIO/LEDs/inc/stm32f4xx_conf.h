#ifndef STM32F4XX_CONF_H_
#define STM32F4XX_CONF_H_

#ifndef assert_param
#define assert_param(x)
#endif

#endif /* STM32F4XX_CONF_H_ */
